#!/bin/sh
python parse.py $1 $2

# kill the spawned python process if the run script is aborted
trap "kill 0" SIGINT SIGTERM EXIT
